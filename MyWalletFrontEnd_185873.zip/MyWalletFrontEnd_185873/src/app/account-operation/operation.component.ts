import { Component, OnInit, Input } from '@angular/core';
import { CustomerService } from '../account.service';
import{ROUTES, Router} from '@angular/router';
import { Customer } from '../accounts';

@Component({
    selector: 'customer-operation',
    templateUrl: './operation.component.html'
    //styleUrls: ['./customer-details.component.css']
  })

export class OperationComponent{
    @Input() customer: Customer;
    mobileno: any;
    amount:any
    fromMobileno:any
    toMobileno:any
    customers: Customer[];

    constructor(private dataService: CustomerService, private router:Router) { }


    private depositeAmount() {
        this.dataService.deposite(this.mobileno,this.amount)
          .subscribe(customers => this.customers = customers);
      }
    
      onDeposite() {
        this.depositeAmount();
        if(confirm("Deposite Successfully!!! You Want To Perfrom Another operation??")){
          window.location.reload();
        }else{
          this.router.navigate(['customer']);
        }
      }

      private withdrawAmount() {
        this.dataService.withdraw(this.mobileno,this.amount)
          .subscribe(customers => this.customers = customers);
      }
    
      onWithdraw() {
        this.withdrawAmount();
        if(confirm("Withdraw Successfully!!! You Want To Perfrom Another operation??")){
          window.location.reload();
        }else{
          this.router.navigate(['customer']);
        }
      }

      private transferAmount() {
        this.dataService.transfer(this.fromMobileno,this.toMobileno,this.amount)
          .subscribe(customers => this.customers = customers);
      }
    
      onTransfer() {
        this.transferAmount();
        if(confirm("Transfer Successfully!!! You Want To Perfrom Another operation??")){
          window.location.reload();
        }else{
          this.router.navigate(['customer']);
        }
      }
}