import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { CustomerService } from '../account.service';
import { Customer } from '../accounts';


@Component({
  selector: 'customers-list',
  templateUrl: './account-list.component.html'
  
})
export class CustomersListComponent implements OnInit {

  customers: Observable<Customer[]>;
  
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
    
    this.reloadData();
  }

  reloadData() {
    this.customers = this.customerService.getCustomersList();
    
    
  }

  delete(){
    if(confirm("Are You Sure Want To Delete All Records???")){
      this.deleteCustomers();
      
    }
  }

  deleteCustomers() {
    this.customerService.deleteAll()
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
          
        },
        error => console.log('ERROR: ' + error));
  }

  
}
