import { Component, OnInit } from '@angular/core';
import{ROUTES, Router} from '@angular/router';
import { Customer } from '../accounts';
import { CustomerService } from '../account.service';

@Component({
  selector: 'create-customer',
  templateUrl: './create-account.component.html'
 
})
export class CreateCustomerComponent implements OnInit {

  customer: Customer = new Customer();
  submitted = false;

  constructor(private customerService: CustomerService, private router:Router) { }

  ngOnInit() {
  }

  newCustomer(): void {
    this.submitted = false;
    this.customer = new Customer();
  }

  save() {
    this.customerService.createCustomer(this.customer)
      .subscribe(data => console.log(data), error => console.log(error.status));
    //this.customer = new Customer();
   
    if(confirm("Account Added Successfully!!! You Want To Add Another Account??")){
      window.location.reload();
    }else{
      this.router.navigate(['customer']);
    }

  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
