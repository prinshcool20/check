import { Component, OnInit, Input } from '@angular/core';
import { CustomerService } from '../account.service';
import { Customer } from '../accounts';

import { CustomersListComponent } from '../accounts-list/account-list.component';

@Component({
  selector: 'customer-details',
  templateUrl: './account-details.component.html'
 
})
export class CustomerDetailsComponent implements OnInit {

  @Input() customer: Customer;

  constructor(private customerService: CustomerService, private listComponent: CustomersListComponent) { }

  ngOnInit() {
    this.customerService.updateCustomer(this.customer. accountId,
      { mobileno: this.customer.mobileno, holdername: this.customer.holdername,balance:this.customer.balance })
      .subscribe(
        data => {
          console.log(data);
          this.customer = data as Customer;
        },
        error => console.log(error));
  }

  
}
