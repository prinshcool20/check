import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomersListComponent } from './accounts-list/account-list.component';
import { CreateCustomerComponent } from './create-account/create-account.component';
import {OperationComponent} from './account-operation/operation.component'
import { SearchCustomersComponent } from './search-accounts/search-accounts.component';


const routes: Routes = [
    { path: '', redirectTo: 'customer', pathMatch: 'full' },
    { path: 'customer', component: CustomersListComponent },
    { path: 'add', component: CreateCustomerComponent },
    { path: 'findbyage', component: SearchCustomersComponent },
    {path:'operation', component: OperationComponent},
    
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }
